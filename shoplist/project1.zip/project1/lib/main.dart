import 'package:flutter/material.dart';
import 'loginscreen.dart';
import 'package:test_project/homescreen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'splashscreen.dart';
void main() => runApp(new MyApp());

class MyApp extends StatelessWidget {
  String uid = "";
  @override
  Widget build(BuildContext ctxt) {
    return new MaterialApp(
        title: "MySampleApplication",
        home: LoginScreen(),
        routes: <String, WidgetBuilder>{
          '/homepage': (BuildContext context) => HomeScreen(uid: uid),
          '/login':(BuildContext context) => LoginScreen(),
        });
  }

  
}
